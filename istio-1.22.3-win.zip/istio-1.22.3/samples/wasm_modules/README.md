# WASM demo

`header_injector` is used for istio e2e tests, more tests can be found [here](https://github.com/istio-ecosystem/wasm-extensions).
